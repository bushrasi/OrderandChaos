/**
 * Developer: Bushra Al Sibai
 * App: Order and Chaos
 * application tested on 4.7,768 x 1280, xhdpi(Nexus4)
 */
package com.orderandchaosgame.orderandchaos;

import android.app.Activity;
import android.os.Bundle;

public class aboutActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_app);
    }

}
